
package t3a5;

import java.util.Scanner;

public class T3A5 {
    
        
    public static void main(String[] args) {
        menu();
    }
    
    public static void menu(){
        
        Cuenta cuenta = new Cuenta();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("""
                           Bienvenid@ a Banco Patito\u00bfQu\u00e9 desae realizar?
                           
                           1. Consultar saldo
                           2. Consultar estado de cuenta
                           3. Retirar efectivo
                           4. Otras opciones
                           5. Salir""");
        
        int operacion = scanner.nextInt();
        
        switch (operacion){
            
            case 1:
                cuenta.consultarSaldo();
                break;
                
            case 2:
                cuenta.estadoCuenta();
                break;
                
            case 3:
                cuenta.retirarEfectivo();
                break;
                
            case 4:
                System.out.println("""
                                   1. Seguros
                                   2. Creditos
                                   Elija uno: """);
                int opcion = scanner.nextInt();
               
                switch(opcion){
                    case 1 -> cuenta.seguros();
                    
                    case 2 -> cuenta.creditos();
                      
                    default -> System.err.println("Elija una opcion valida");
                        
                }

                
            case 5:
                cuenta.salir();
                break;
                
                
            default:
                System.err.println("Elija una opcion v�lida");
                
        }
    }
}
