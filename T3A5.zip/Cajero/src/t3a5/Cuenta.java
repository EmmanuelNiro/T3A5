package t3a5;


public class Cuenta {
    private String numeroCuenta;
    private int pin;
    private float saldo;

public Cuenta (){}

    public Cuenta(String numeroCuenta, int pin, float saldo) {
        this.numeroCuenta = numeroCuenta;
        this.pin = pin;
        this.saldo = saldo;
    }
public void consultarSaldo(){
    System.out.println("Tienes un saldo de: "+getSaldo());

}

    public void estadoCuenta() {
        System.out.println("Estaodo de cuenta\n\n"
                + "Nuemro de cuenta: "+getNumeroCuenta()
                + "\nSaldo: "+getSaldo()
                + "\n\nUltimos movimientos: ");
    }
    
    public void retirarEfectivo(){
        if (getSaldo() > 0){
            System.out.println("�Cuanto desea retirar? ");
            
           
        }else{
            System.out.println("OPERACION INVALIDA"
                    + "\n1. Fondos insuficientes");
        }
    }
    
    public void seguros(){
        
        System.out.println("SEGUROS"
                + "\n1. Para auto"
                + "\n2. Seguro de vida"
                + "\n3. Seguro medico"
                + "\n4. Seguro de vivienda");
    }
    
    public void creditos(){
        System.out.println("CR�DITOS"
                + "\n1. Hipotecario"
                + "\n2. Crediauto"
                + "\n3. Familiar"
                + "\n4. Personal");
    }
    
    public void salir(){
        System.out.println("Retire su tarjeta con cuidado");
    }
@Override
    public String toString(){
    String mensaje = "Numero de cuenta: "+ numeroCuenta;
    return mensaje;
}


    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
        
    
    
}
